import 'package:flutter/material.dart';

class SubCategProducts extends StatelessWidget {
  String mainCategName;
  String subCategName;
  SubCategProducts(
      {Key? key, required this.mainCategName, required this.subCategName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.teal,
        title: Text(subCategName),
      ),
      body: SafeArea(
          child: Center(
        child: Text(
          mainCategName,
          style: const TextStyle(fontFamily: 'FontTwo', fontSize: 30),
        ),
      )),
    );
  }
}
