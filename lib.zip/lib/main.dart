import 'package:flutter/material.dart';
import 'main_screens/customer_home.dart';

void main() {
  runApp(
    MaterialApp(
      theme: ThemeData(
        // for later use in a card. Awesome...
        //cardColor: NeumorphicColors.background,
        tabBarTheme: const TabBarTheme(
          labelColor: Colors.brown,
          indicatorColor: Colors.brown,
        ),
        // bottomAppBarTheme: const BottomAppBarTheme(color: Colors.teal),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(
            fontFamily: 'FontMain',
            fontSize: 24,
          ),
          titleMedium: TextStyle(fontFamily: 'FontTwo', fontSize: 17.5),
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: const CustomerHomeScreen(),
    ),
  );
}
