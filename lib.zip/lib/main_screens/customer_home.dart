import 'package:chawla_trial_udemy/main_screens/category.dart';
import 'package:chawla_trial_udemy/main_screens/neumorphic_practice.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'home.dart';

class CustomerHomeScreen extends StatefulWidget {
  const CustomerHomeScreen({Key? key}) : super(key: key);

  @override
  State<CustomerHomeScreen> createState() => _CustomerHomeScreenState();
}

class _CustomerHomeScreenState extends State<CustomerHomeScreen> {
  // list of pages to be displayed through Bottom Navigation Bar//
  List<Widget> pages = const [
    HomeScreen(),
    Category(),
    Center(
      child: Text('Page Three'),
    ),
    /**Neumorphic package mein problem aa rahi thi
     * isliye usko totally disabled kr diya, from the dependecies too. */
    // PageThree(),
    PageFour(),
    PageFive(),
  ];
  int _currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        //****starts***//
        elevation: 0,
        type: BottomNavigationBarType.fixed,

        selectedItemColor: CupertinoColors.systemTeal,

        unselectedItemColor: CupertinoColors.systemGrey,

        // works only when type is fixed. See above.//
        backgroundColor: Colors.white,

        currentIndex: _currentIndex,

        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },

        //must be as many in numbers as our upper list is.//
        items: const [
          BottomNavigationBarItem(
            label: 'Home',
            icon: Icon(CupertinoIcons.home),
          ),
          BottomNavigationBarItem(
            label: 'Category',
            icon: Icon(CupertinoIcons.search),
          ),
          BottomNavigationBarItem(
            label: 'Stores',
            icon: Icon(CupertinoIcons.building_2_fill),
          ),
          BottomNavigationBarItem(
            label: 'Shopping Cart',
            icon: Icon(CupertinoIcons.shopping_cart),
          ),
          BottomNavigationBarItem(
            label: 'Profile',
            icon: Icon(CupertinoIcons.person),
          )
        ],

        //****ends ***//
      ),

      // body depends upon the page we tapped from the bottom navigation//
      body: SafeArea(child: pages[_currentIndex]),
    );
  }
}

class PageFour extends StatefulWidget {
  const PageFour({Key? key}) : super(key: key);

  @override
  State<PageFour> createState() => _PageFourState();
}

class _PageFourState extends State<PageFour> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      appBar: CupertinoNavigationBar(
        middle: Text('Chawla Plastics Page Four'),
      ),
      body: Center(
        child: Text('Shopping Cart'),
      ),
    );
  }
}

class PageFive extends StatefulWidget {
  const PageFive({Key? key}) : super(key: key);

  @override
  State<PageFive> createState() => _PageFiveState();
}

class _PageFiveState extends State<PageFive> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      appBar: CupertinoNavigationBar(
        middle: Text('Chawla Plastics Page Five'),
      ),
      body: Center(
        child: Text('Profile Page'),
      ),
    );
  }
}
