import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../my_widgets/search_box.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: 0,
      length: 9,
      child: Scaffold(
        appBar: AppBar(
          // centerTitle: true,
          title: const SearchBoxAppBar(),
          //,
          elevation: 0,
          bottom: const TabBar(isScrollable: true, tabs: [
            RepeatedTab(
              tabName: 'Men',
            ),
            RepeatedTab(
              tabName: 'Women',
              // iconName: FontAwesomeIcons.googlePay,
            ),
            RepeatedTab(
              tabName: 'Shoes',
              //  iconName: CupertinoIcons.bubble_left_bubble_right_fill,
            ),
            RepeatedTab(tabName: 'Bags'),
            RepeatedTab(tabName: 'Electronics'),
            RepeatedTab(tabName: 'Accessories'),
            RepeatedTab(tabName: 'Home & Garden'),
            RepeatedTab(tabName: 'Kids'),
            RepeatedTab(tabName: 'Beauty')
          ]),
        ),
        body: SafeArea(
          child: TabBarView(
            children: [
              const Center(
                child: Text(
                  'Text from Tab One',
                  style: TextStyle(fontSize: 30),
                ),
              ),
              Center(
                  child: Text(
                'Text from Tab Two',
                style: Theme.of(context).textTheme.titleLarge,
              )),
              Center(
                  child: Text('Text from Tab Three',
                      style: Theme.of(context).textTheme.titleLarge)),
              Center(
                  child: Text(
                'Text from Tab Four',
                style: Theme.of(context).textTheme.titleMedium,
              )),
              const Center(child: Text('Text from Tab Five')),
              const Center(child: Text('Text from Tab Six')),
              const Center(child: Text('Text from Tab Seven')),
              const Center(child: Text('Text from Tab Eight')),
              const Center(child: Text('Text from Tab Nine'))
            ],
          ),
        ),
      ),
    );
  }
}

class RepeatedTab extends StatelessWidget {
  final String tabName;

  /** ye Icons lene se appBar ke title ki symmetry mein bahut difference aata hai;
   * sb kuch trial krke ke baad isko deactivate kr diya.
   * */

  //final IconData? iconName;

  const RepeatedTab({
    super.key,
    required this.tabName,
  });

  @override
  Widget build(BuildContext context) {
    return Tab(
      text: tabName,

      // icon: Icon(iconName),
    );
  }
}
