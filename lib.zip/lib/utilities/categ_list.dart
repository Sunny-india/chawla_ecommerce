class Categories {
  static List<String> maincateg = [
    'men',
    'women',
    'accessories',
    'shoes',
    'electronics',
    'shoes',
    'home & garden',
    'beauty',
    'kids',
    'bags'
  ];

  List<String> men = [
    'shirt',
    't-shirt',
    'jacket',
    'vest',
    'coat',
    'jeans',
    'shorts',
    'suit',
    'others'
  ];

  List<String> women = [
    'dress',
    '2pcs sets',
    't-shirt',
    'top',
    'skirt',
    'jeans',
    'pants',
    'coat',
    'jacket',
    'other'
  ];

  List<String> electronics = [
    'phone',
    'computer',
    'laptop',
    'smart tv',
    'phone holder',
    'charger',
    'usb cables',
    'head phones',
    'smart watch',
    'tablet',
    'mouse',
    'keyboard',
    'gaming',
    'ohter'
  ];

  List<String> accessories = [
    'slippers',
    'classic',
    'casual',
    'boots',
    'canvas',
  ];

  List<String> homeGarden = [
    'Garden 1',
    'Garden 2',
    'Garden 3',
    'Garden 4',
    'Garden 5',
  ];

  List<String> shoes = [
    'slippers',
    'classic',
    'casual',
    'boots',
    'canvas',
  ];

  List<String> bags = [
    'Dockers',
    'Holdaals',
    'Office',
    'Casuals',
    'Party',
  ];
}
